package org.transgalactica.management.data.referentiel.bo;

public enum EmployeType {

	PILOTE, MECANICIEN;
}
