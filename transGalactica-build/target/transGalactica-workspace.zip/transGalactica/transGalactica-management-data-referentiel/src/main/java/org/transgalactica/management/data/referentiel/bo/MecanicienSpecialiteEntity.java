package org.transgalactica.management.data.referentiel.bo;

import java.io.Serializable;

public interface MecanicienSpecialiteEntity extends Serializable {

	String getNomSpecialite();
}
