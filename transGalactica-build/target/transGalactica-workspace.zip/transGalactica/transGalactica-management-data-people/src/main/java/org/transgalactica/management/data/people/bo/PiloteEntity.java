package org.transgalactica.management.data.people.bo;

public interface PiloteEntity extends EmployeEntity {

	int getNombreHeuresVol();

	void setNombreHeuresVol(int nombreHeuresVol);
}
