-- ============================================================================
-- Script de creation des données de reference
-- ============================================================================

-- ----------------------------------------------------------------------------
-- Table MECANICIENS_SPECIALITES
-- ----------------------------------------------------------------------------
INSERT INTO MECANICIENS_SPECIALITES VALUES (1, 'Moteur');
INSERT INTO MECANICIENS_SPECIALITES VALUES (2, 'Hyperpropulsion');
INSERT INTO MECANICIENS_SPECIALITES VALUES (3, 'Armement');
INSERT INTO MECANICIENS_SPECIALITES VALUES (4, 'Blindage');
INSERT INTO MECANICIENS_SPECIALITES VALUES (5, 'Electronique');

-- ----------------------------------------------------------------------------
-- Validation traitement
-- ----------------------------------------------------------------------------
COMMIT;
