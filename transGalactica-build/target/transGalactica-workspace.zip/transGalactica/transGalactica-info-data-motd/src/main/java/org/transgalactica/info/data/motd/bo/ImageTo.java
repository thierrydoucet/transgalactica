package org.transgalactica.info.data.motd.bo;


public interface ImageTo {

	String getUrl();

	String getTexteAlternatif();
}