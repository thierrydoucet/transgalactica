package org.transgalactica.data.rest.bo;

import java.io.Serializable;

public interface HangarSearchCriteria extends Serializable {

	void setLocalisationHangar(String localisationHangar);

	String getLocalisationHangar();

}