package org.transgalactica.data.rest.bo;


public interface PiloteTo extends EmployeTo {

	int getNombreHeuresVol();

	void setNombreHeuresVol(int nombreHeuresVol);
}
