package org.transgalactica.data.rest.bo;

import java.util.List;

public interface MecanicienTo extends EmployeTo {

	List<String> getSpecialites();
}
