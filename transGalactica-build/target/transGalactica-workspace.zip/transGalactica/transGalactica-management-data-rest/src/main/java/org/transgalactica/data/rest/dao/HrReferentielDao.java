package org.transgalactica.data.rest.dao;

import java.util.List;

public interface HrReferentielDao {

	List<String> getAllEmployeType();

	List<String> getAllMecanicienspecialite();
}
