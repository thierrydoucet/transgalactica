package org.transgalactica.management.rest.hr.data;

public interface PiloteCommand extends EmployeCommand {

	int getNombreHeuresVol();

	void setNombreHeuresVol(int nombreHeuresVol);
}