package org.transgalactica.management.rest.hr.data;

import java.io.Serializable;

public interface PiloteDetailDto extends EmployeDetailDto, Serializable {

	int getNombreHeuresVol();
}