package org.transgalactica.fwk.test.domaine.bo;

import java.io.Serializable;

public interface IDummyTo extends Serializable {

	String getDummyAttribut();

	void setDummyAttribut(String dummyAttribut);
}
