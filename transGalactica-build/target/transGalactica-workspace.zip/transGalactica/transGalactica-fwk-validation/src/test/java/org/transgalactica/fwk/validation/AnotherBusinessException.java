package org.transgalactica.fwk.validation;

import org.transgalactica.fwk.validation.exception.BusinessException;

public class AnotherBusinessException extends BusinessException {

	private static final long serialVersionUID = 1L;

}
