package org.transgalactica.fwk.domain.bean.factory;

import java.io.Serializable;

public interface IDummyTo extends Serializable {

	String getDummyAttribut();

	void setDummyAttribut(String dummyAttribut);
}
