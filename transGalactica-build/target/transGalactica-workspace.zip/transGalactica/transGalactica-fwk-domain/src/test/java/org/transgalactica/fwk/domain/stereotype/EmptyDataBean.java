package org.transgalactica.fwk.domain.stereotype;

import org.transgalactica.fwk.domain.stereotype.DataBean;

@DataBean
public class EmptyDataBean {

}
