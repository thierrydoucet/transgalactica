package org.transgalactica.fwk.domain.bean.factory;

public interface IDummyBo {

	Long getIdentifier();

}
