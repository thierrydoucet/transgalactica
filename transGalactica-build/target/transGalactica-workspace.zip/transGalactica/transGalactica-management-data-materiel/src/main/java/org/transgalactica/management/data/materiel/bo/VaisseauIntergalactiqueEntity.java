package org.transgalactica.management.data.materiel.bo;

public interface VaisseauIntergalactiqueEntity extends VaisseauEntity {

	short getMultiplicateurHyperdrive();

	void setMultiplicateurHyperdrive(short multiplicateurHyperdrive);
}
